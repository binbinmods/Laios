# 0.1.1

Nerfed bonus charges on Faiths shield.

# 0.1.0

Initial concept
